# uaal-policy-dsl

Declarative, auditor-friendly policy language for AI authorization.

Separates model intent from action permission.
Designed for regulated environments.

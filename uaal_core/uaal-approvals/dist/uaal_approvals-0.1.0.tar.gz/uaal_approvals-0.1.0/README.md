# uaal-approvals

Mandatory human approval layer for high-risk AI actions.

This library pauses AI execution until an explicit human decision is recorded.

Designed for EU AI Act, RBI, and SOC2 compliance.
